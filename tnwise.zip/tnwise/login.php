<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);

    // Check if user exists
    $sql = "SELECT * FROM users WHERE name = ? AND email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        echo "Login successful! Welcome, " . htmlspecialchars($name);
    } else {
        echo "Invalid credentials!";
    }

    $stmt->close();
    $conn->close();
}
?>
