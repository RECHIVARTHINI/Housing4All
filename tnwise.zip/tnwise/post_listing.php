<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "housing_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(["message" => "Database connection failed: " . $conn->connect_error]));
}

$title = $_POST["title"];
$price = $_POST["price"];
$bhk = $_POST["bhk"];
$description = $_POST["description"];
$accessibility = $_POST["accessibility"];

$sql = "INSERT INTO listings (title, price, bhk, description, accessibility) 
        VALUES ('$title', '$price', '$bhk', '$description', '$accessibility')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "Listing added successfully!"]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error]);
}

$conn->close();
?>
