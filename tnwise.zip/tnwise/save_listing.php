<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "housing_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$title = $_POST['title'] ?? '';
$location = $_POST['location'] ?? '';
$price = $_POST['price'] ?? 0;
$bhk = $_POST['bhk'] ?? '';
$accessibility = $_POST['accessibility'] ?? '';

// Insert into database
$sql = "INSERT INTO listings (title, location, price, bhk, accessibility_features) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssdis", $title, $location, $price, $bhk, $accessibility);

if ($stmt->execute()) {
    echo "Listing posted successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
