<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$host = "localhost";
$dbname = "housing_db";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

if ($_POST['action'] == 'getAffordableHouses') {
    $income = (int) $_POST['income']; // Convert to integer

    $stmt = $pdo->prepare("SELECT * FROM listings WHERE price <= ?");
    $stmt->execute([$income]);
    $houses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($houses)) {
        echo json_encode(["status" => "success", "houses" => $houses]);
    } else {
        echo json_encode(["status" => "no_results", "message" => "No houses match your income."]);
    }
    exit();
}

// If no action matched, return error
echo json_encode(["status" => "error", "message" => "Invalid request"]);
exit();
?>

