<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

file_put_contents("debug_log.txt", "[" . date('Y-m-d H:i:s') . "] Incoming Request: " . print_r($_POST, true), FILE_APPEND);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housing_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

if (!isset($_POST['message'])) {
    echo json_encode(["status" => "error", "message" => "No message received"]);
    exit();
}

$message = strtolower($_POST['message']);

// Function to extract numbers (e.g., "1 crore" -> 10000000)
function convertToNumber($text) {
    $text = strtolower($text);
    $text = str_replace(" ", "", $text);
    if (strpos($text, "crore") !== false) {
        preg_match('/(\d+(\.\d+)?)/', $text, $match);
        return isset($match[1]) ? (floatval($match[1]) * 10000000) : 0;
    } elseif (strpos($text, "lakh") !== false) {
        preg_match('/(\d+(\.\d+)?)/', $text, $match);
        return isset($match[1]) ? (floatval($match[1]) * 100000) : 0;
    } else {
        preg_match('/(\d+)/', $text, $match);
        return isset($match[1]) ? (int) $match[1] : 0;
    }
}

// Extract BHK, price, and accessibility features
$bhk = 0;
$price = 0;
$accessibility_features = [];

// Match BHK and price
if (preg_match('/(\d+)\s*bhk.*?(\d+\s*(?:crore|lakh|\d+))/', $message, $matches)) {
    $bhk = (int) $matches[1];
    $price = convertToNumber($matches[2]);
}

// Extract accessibility features
$possible_features = ["wheelchair", "elevator", "senior-friendly", "ramp"];
foreach ($possible_features as $feature) {
    if (strpos($message, $feature) !== false) {
        $accessibility_features[] = $feature;
    }
}

// Log extracted values
file_put_contents("debug_log.txt", "[" . date('Y-m-d H:i:s') . "] Extracted: BHK=$bhk, Price=$price, Features=" . implode(", ", $accessibility_features) . "\n", FILE_APPEND);

// Build SQL Query
$sql = "SELECT * FROM listings WHERE price <= ? AND bhk = ?";
if (!empty($accessibility_features)) {
    foreach ($accessibility_features as $feature) {
        $sql .= " AND accessibility_features LIKE ?";
    }
}

$stmt = $conn->prepare($sql);

// Bind Parameters
$params = [$price, $bhk];
$types = "ii";
foreach ($accessibility_features as $feature) {
    $params[] = "%" . $feature . "%";
    $types .= "s";
}

$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$houses = [];
while ($row = $result->fetch_assoc()) {
    $houses[] = $row;
}

// Log SQL Query & Result
file_put_contents("debug_log.txt", "[" . date('Y-m-d H:i:s') . "] SQL Query: $sql\n", FILE_APPEND);
file_put_contents("debug_log.txt", "[" . date('Y-m-d H:i:s') . "] Query Result: " . print_r($houses, true) . "\n", FILE_APPEND);

if (!empty($houses)) {
    echo json_encode(["status" => "success", "houses" => $houses]);
} else {
    echo json_encode(["status" => "no_results", "message" => "No houses found matching your criteria."]);
}

$conn->close();
?>
