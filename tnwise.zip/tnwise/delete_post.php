<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housing_db";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed"]));
}

// Get post ID from request
$data = json_decode(file_get_contents("php://input"), true);
if (!isset($data["id"])) {
    echo json_encode(["success" => false, "error" => "Invalid post ID"]);
    exit;
}

$postId = $data["id"];

// Get image path before deleting
$stmt = $conn->prepare("SELECT image FROM community_posts WHERE id = ?");
$stmt->bind_param("i", $postId);
$stmt->execute();
$stmt->bind_result($imagePath);
$stmt->fetch();
$stmt->close();

// Delete image file if exists
if ($imagePath && file_exists($imagePath)) {
    unlink($imagePath);
}

// Delete post from database
$stmt = $conn->prepare("DELETE FROM community_posts WHERE id = ?");
$stmt->bind_param("i", $postId);
$success = $stmt->execute();
$stmt->close();
$conn->close();

echo json_encode(["success" => $success]);
?>
