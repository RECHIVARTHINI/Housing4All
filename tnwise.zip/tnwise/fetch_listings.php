<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "housing_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed: " . $conn->connect_error]));
}

// Get filters from request
$minPrice = isset($_GET['minPrice']) ? (int)$_GET['minPrice'] : 0;
$maxPrice = isset($_GET['maxPrice']) ? (int)$_GET['maxPrice'] : PHP_INT_MAX;
$bhk = isset($_GET['bhk']) ? (int)$_GET['bhk'] : 0;
$accessibility = isset($_GET['accessibility']) ? explode(",", $_GET['accessibility']) : [];

// Base query
$sql = "SELECT * FROM listings WHERE price BETWEEN ? AND ?";
$params = [$minPrice, $maxPrice];
$types = "ii";

// Add BHK filter
if ($bhk > 0) {
    $sql .= " AND bhk = ?";
    $params[] = $bhk;
    $types .= "i";
}

// Add accessibility filters
if (!empty($accessibility) && count($accessibility) > 0) {
    $sql .= " AND (";
    $placeholders = [];
    foreach ($accessibility as $feature) {
        $placeholders[] = "FIND_IN_SET(?, accessibility_features)";
        $params[] = $feature;
        $types .= "s";
    }
    $sql .= implode(" OR ", $placeholders) . ")";
}

// Prepare and execute query
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die(json_encode(["error" => "Query preparation failed: " . $conn->error]));
}

$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$listings = [];
while ($row = $result->fetch_assoc()) {
    $listings[] = $row;
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($listings);

$stmt->close();
$conn->close();
?>
