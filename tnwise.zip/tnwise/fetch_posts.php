<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json"); // Ensure JSON response

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housing_db";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed"]));
}

// Fetch all posts (MAKE SURE TO INCLUDE PHONE COLUMN)
$result = $conn->query("SELECT id, username, phone, content, image, created_at FROM community_posts ORDER BY created_at DESC");
$posts = [];

while ($row = $result->fetch_assoc()) {
    $row["image"] = $row["image"] ? "http://localhost/inclusive_housing/tnwise/" . $row["image"] : null;
    $posts[] = $row;
}

$conn->close();
echo json_encode($posts);
?>
