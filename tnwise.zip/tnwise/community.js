fetch("http://localhost/save_post.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
        username: "TestUser",
        post_text: "This is a test post.",
        phone: "9876543210"
    })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error("Error:", error));
