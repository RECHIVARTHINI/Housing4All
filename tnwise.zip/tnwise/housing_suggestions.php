<?php
// Connect to database
$host = 'localhost';
$dbname = 'housing_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(["error" => "Database connection failed: " . $e->getMessage()]));
}

// Check if income is received
if (!isset($_POST['income'])) {
    echo json_encode([]);
    exit();
}

$income = (int) $_POST['income'];
$affordablePrice = $income * 5; // Example: 5x monthly income is affordable

// Fetch affordable houses
$sql = "SELECT * FROM listings WHERE price <= ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$affordablePrice]);

$houses = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($houses);
?>
