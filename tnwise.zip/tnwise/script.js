document.addEventListener("DOMContentLoaded", function () {
    loadListings(); // Load all listings when the page loads

    document.getElementById("searchForm").addEventListener("submit", function (event) {
        event.preventDefault();
        searchHouses();
    });

    setupDarkModeToggle();
});

// ✅ Function to Fetch and Display Listings
function loadListings(minPrice = 0, maxPrice = 999999) {
    fetch(`fetch_listings.php?min_price=${minPrice}&max_price=${maxPrice}`)
        .then(response => response.json())
        .then(data => {
            console.log("Fetched Data:", data); // Debugging output
            let listingsContainer = document.getElementById("listings-container");
            listingsContainer.innerHTML = ""; // Clear previous listings

            if (!Array.isArray(data) || data.length === 0 || data.message) {
                listingsContainer.innerHTML = `<p>No listings found</p>`;
                return;
            }

            data.forEach(listing => {
                let houseCard = document.createElement("div");
                houseCard.classList.add("house-card");

                houseCard.innerHTML = `
                    <img src="images/${listing.image_url}" alt="${listing.title}" width="150" 
                         onerror="this.onerror=null; this.src='default.jpg';">
                    <h3>${listing.title}</h3>
                    <p><strong>Price:</strong> ₹${listing.price}</p>
                    <p>${listing.description}</p>
                `;

                listingsContainer.appendChild(houseCard);
            });
        })
        .catch(error => {
            console.error("❌ Error fetching data:", error);
            document.getElementById("listings-container").innerHTML = "<p>Error loading listings.</p>";
        });
}

// ✅ Function to Search Houses Based on Min/Max Price
function searchHouses() {
    let minPrice = document.getElementById("minPrice").value || 0;
    let maxPrice = document.getElementById("maxPrice").value || 999999;
    loadListings(minPrice, maxPrice);
}

// ✅ Dark Mode Toggle
function setupDarkModeToggle() {
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    const body = document.body;

    if (localStorage.getItem("dark-mode") === "enabled") {
        body.classList.add("dark-mode");
        darkModeToggle.textContent = "☀ Light Mode";
    }

    darkModeToggle.addEventListener("click", function () {
        body.classList.toggle("dark-mode");

        if (body.classList.contains("dark-mode")) {
            localStorage.setItem("dark-mode", "enabled");
            darkModeToggle.textContent = "☀ Light Mode";
        } else {
            localStorage.setItem("dark-mode", "disabled");
            darkModeToggle.textContent = "🌙 Dark Mode";
        }
    });
}
document.getElementById("searchForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const minPrice = document.getElementById("minPrice").value;
    const maxPrice = document.getElementById("maxPrice").value;
    const bhk = document.getElementById("bhk").value;

    // Get selected accessibility options
    let accessibility = [];
    document.querySelectorAll("input[name='accessibility']:checked").forEach(input => {
        accessibility.push(input.value);
    });

    const queryParams = new URLSearchParams({
        minPrice: minPrice,
        maxPrice: maxPrice,
        bhk: bhk,
        accessibility: accessibility.join(",")  // Convert to comma-separated string
    });

    fetch("fetch_listings.php?" + queryParams.toString())
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById("listings-container");
            container.innerHTML = "";

            if (data.length === 0) {
                container.innerHTML = "<p>No matching listings found.</p>";
            } else {
                data.forEach(house => {
                    const houseElement = document.createElement("div");
                    houseElement.classList.add("house-card");
                    houseElement.innerHTML = `
                        <h3>${house.title}</h3>
                        <p>Location: ${house.location}</p>
                        <p>Price: $${house.price}</p>
                        <p>BHK: ${house.bhk}</p>
                        <p>Accessibility: ${house.accessibility_features || "None"}</p>
                    `;
                    container.appendChild(houseElement);
                });
            }
        })
        .catch(error => console.error("Error fetching listings:", error));
});
